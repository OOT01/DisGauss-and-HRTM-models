import json
from importlib.resources import files
from pathlib import Path

import pandas as pd

from dgm_hrtm.functions.func_main import main_experiment


def get_results_dir(base_dir=None) -> Path:
    """
    Return the RESULTS directory.

    If base_dir is None, RESULTS is created in the current working directory.
    """
    if base_dir is None:
        results_dir = Path.cwd() / "RESULTS"
    else:
        results_dir = Path(base_dir) / "RESULTS"

    results_dir.mkdir(parents=True, exist_ok=True)
    return results_dir


def load_radionuclide_data() -> pd.DataFrame:
    """
    Load radionuclide data from the packaged CSV file.
    """
    rad_path = files("dgm_hrtm.data").joinpath("radionuclidos.csv")
    return pd.read_csv(rad_path, comment="#")


def load_dcf_data(population: str) -> dict:
    """
    Load the appropriate DCF database according to the selected population.
    """
    population = str(population).strip().lower()

    if population == "worker":
        dcf_path = files("dgm_hrtm.data").joinpath("dcf_workers.json")
    elif population == "public":
        dcf_path = files("dgm_hrtm.data").joinpath("dcf_public.json")
    else:
        raise ValueError(f"Unknown population: {population}")

    with open(dcf_path, "r", encoding="utf-8") as f:
        return json.load(f)


def run_simulation(config, base_dir=None):
    """
    Run one full Gaussian dispersion + HRTM simulation.

    Parameters
    ----------
    config
        SimulationConfig instance.
    base_dir : str | Path | None
        Base directory where RESULTS will be created.
        If None, RESULTS is created in the current working directory.

    Returns
    -------
    Path
        Path to the RESULTS directory.
    """
    results_dir = get_results_dir(base_dir=base_dir)
    df_rad = load_radionuclide_data()
    dcf_data = load_dcf_data(config.population)

    main_experiment(
        config=config,
        df_rad=df_rad,
        dcf_data=dcf_data,
        results_dir=str(results_dir),
    )

    return results_dir